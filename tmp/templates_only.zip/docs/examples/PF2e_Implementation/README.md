# PF2e Implementation (TIER 2 placeholder)

This folder will serve as an example for a Pathfinder 2e fill-in once someone adapts the template.

Suggested contents:
- `system-profiles/Pathfinder2/parser.py` — PF2-specific stat block parser (using `TEMPLATE_StatBlockParser.py` as a starting point)
- `system-profiles/Pathfinder2/adapter.py` — mapping to canonical fields
- `system-profiles/Pathfinder2/schema.json` — PF2 mapping of fields
- test fixtures and a short `README.md`

This is intentionally empty for now; it exists to remind you how to implement a second system.
